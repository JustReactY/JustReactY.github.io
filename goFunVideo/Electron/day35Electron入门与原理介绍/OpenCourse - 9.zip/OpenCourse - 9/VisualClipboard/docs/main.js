import Vue from 'vue'
import App from './APP.vue'
import 'melody.css'

new Vue({
  render: h => h(App)
}).$mount('#app')
